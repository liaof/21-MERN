const User = require('./User');
const Thought = require('./Thought');

module.exports = { User, Thought };
